module.exports = {
    production: true,
    development: false,
    node: false
};
