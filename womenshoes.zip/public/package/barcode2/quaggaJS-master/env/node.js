module.exports = {
    production: true,
    development: false,
    node: true
};
