<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="txt-light"><?php echo e(date('d M, Y', strtotime($date))); ?></li>
<?php
$transactions = \App\Transaction::select('kode_transaksi')
->whereDate('transactions.created_at', $date)
->distinct()
->latest()
->get();
?>
<div class="table-responsive">
  <table class="table table-custom">
    <tr>
      <th>Kode Transaksi</th>
      <th>Total</th>
      <th>Bayar</th>
      <th>Kembali</th>
      <th></th>
    </tr>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <?php
      $transaksi = \App\Transaction::where('kode_transaksi', $transaction->kode_transaksi)
      ->select('transactions.*')
      ->first();
      $products = \App\Transaction::where('kode_transaksi', $transaction->kode_transaksi)
      ->select('transactions.*')
      ->get();
      $tgl_transaksi = \App\Transaction::where('kode_transaksi', '=' , $transaction->kode_transaksi)
      ->select('created_at')
      ->first();
      ?>
      <td class="td-1">
        <span class="d-block font-weight-bold big-font"><?php echo e($transaction->kode_transaksi); ?></span>
        <span class="d-block mt-2 txt-light"><?php echo e(date('d M, Y', strtotime($tgl_transaksi->created_at)) . ' pada ' . date('H:i', strtotime($tgl_transaksi->created_at))); ?></span>
      </td>
      <td><span class="ammount-box bg-green"><i class="mdi mdi-coin"></i></span>Rp. <?php echo e(number_format($transaksi->total,2,',','.')); ?></td>
      <td class="text-success font-weight-bold">- Rp. <?php echo e(number_format($transaksi->bayar,2,',','.')); ?></td>
      <td>Rp. <?php echo e(number_format($transaksi->kembali,2,',','.')); ?></td>
      <td>
        <button class="btn btn-selengkapnya font-weight-bold" type="button" data-target="#dropdownTransaksi<?php echo e($transaction->kode_transaksi); ?>"><i class="mdi mdi-chevron-down arrow-view"></i></button>
      </td>
    </tr>
    <tr id="dropdownTransaksi<?php echo e($transaction->kode_transaksi); ?>" data-status="0" class="dis-none">
      <td colspan="5" class="dropdown-content">
        <div class="d-flex justify-content-between align-items-center">
          <div class="kasir mb-3">
            Kasir : <?php echo e($transaksi->kasir); ?>

          </div>
          <div class="total-barang mb-3">
            Total Barang : <?php echo e($products->count()); ?>

          </div>
        </div>
        <table class="table">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><span class="numbering"><?php echo e($loop->iteration); ?></span></td>
            <td>
              <span class="bold-td"><?php echo e($product->nama_barang); ?></span>
              <span class="light-td mt-1"><?php echo e($product->kode_barang); ?></span>
            </td>
            <td><span class="ammount-box-2 bg-secondary"><i class="mdi mdi-cube-outline"></i></span> <?php echo e($product->jumlah); ?></td>
            <td>
              <span class="light-td mb-1">Harga</span>
              <span class="bold-td">Rp. <?php echo e(number_format($product->harga,2,',','.')); ?></span>
            </td>
            <td>
              <span class="light-td mb-1">Total Barang</span>
              <span class="bold-td">Rp. <?php echo e(number_format($product->total_barang,2,',','.')); ?></span>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ipos-system\resources\views/report/report_transaction_filter.blade.php ENDPATH**/ ?>