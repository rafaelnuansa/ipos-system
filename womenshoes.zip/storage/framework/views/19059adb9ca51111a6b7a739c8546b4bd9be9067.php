<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		*{
			font-family: Arial, sans-serif;
		}

		.center{
			text-align: center;
		}

		.right{
			text-align: right;
		}

		.left{
			text-align: left;
		}

		p{
			font-size: 10px;
		}

		.top-min{
			margin-top: -10px;
		}

		.uppercase{
			text-transform: uppercase;
		}

		.bold{
			font-weight: bold;
		}

		.d-block{
			display: block;
		}

		hr{
			border: 0;
			border-top: 1px solid #000;
		}

		.hr-dash{
			border-style: dashed none none none;
		}

		table{
			font-size: 10px;
		}

		table thead tr td{
			padding: 5px;
		}

		.w-100{
			width: 100%;
		}

		.line{
			border: 0;
			border-top: 1px solid #000;
			border-style: dashed none none none;
		}

		.body{
			margin-top: -10px;
		}

		.b-p{
			font-size: 12px !important;
		}

		.w-long{
			width: 80px;
		}
	</style>
</head>
<body>
	<div class="header">
		<p class="uppercase bold d-block center b-p"><?php echo e($market->nama_toko); ?></p>
		<p class="top-min d-block center"><?php echo e($market->alamat); ?></p>
		<p class="top-min d-block center"><?php echo e($market->no_telp); ?></p>
		<hr class="hr-dash">
		<table class="w-100">
			<tr>
				<td class="left w-long">Kode Transaksi : </td>
				<td class="left"><?php echo e($transaction->kode_transaksi); ?></td>
				<td class="right">Kasir : </td>
				<?php
				$nama_kasir = explode(' ', $transaction->kasir);
				$kasir = $nama_kasir[0];
				?>
				<td class="right"><?php echo e($kasir); ?></td>
			</tr>
			<tr>
				<td></td>
				<td class="left" colspan="3"><?php echo e(date('d M, Y', strtotime($transaction->created_at))); ?></td>
			</tr>
		</table>
		<hr class="hr-dash">
	</div>
	<div class="body">
		<table class="w-100">
			<thead>
				<tr>
					<td>Nama Barang</td>
					<td>Qty</td>
					<td>Harga</td>
					<td>Jumlah</td>
				</tr>
				<tr>
					<td colspan="4" class="line"></td>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($transaksi->nama_barang); ?></td>
					<td><?php echo e($transaksi->jumlah); ?></td>
					<td><?php echo e(number_format($transaksi->harga,2,',','.')); ?></td>
					<td><?php echo e(number_format($transaksi->total_barang,2,',','.')); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<hr class="hr-dash">
		<table class="w-100">
			<tr>
				<td class="left">Subtotal (Jumlah : <?php echo e($transactions->count()); ?>)</td>
				<td class="right"><?php echo e(number_format($transaction->subtotal,2,',','.')); ?></td>
			</tr>
			<tr>
				<td class="left">Diskon (<?php echo e($transaction->diskon); ?>%)</td>
				<td class="right"><?php echo e(number_format($diskon,2,',','.')); ?></td>
			</tr>
			<tr>
				<td class="left">Total</td>
				<td class="right"><?php echo e(number_format($transaction->total,2,',','.')); ?></td>
			</tr>
		</table>
		<hr class="hr-dash">
		<table class="w-100">
			<tr>
				<td class="left">Bayar</td>
				<td class="right"><?php echo e(number_format($transaction->bayar,2,',','.')); ?></td>
			</tr>
			<tr>
				<td class="left">Kembali</td>
				<td class="right"><?php echo e(number_format($transaction->kembali,2,',','.')); ?></td>
			</tr>
		</table>
		<hr class="hr-dash">
	</div>
	<div class="footer">
		<p class="center">Terima Kasih Telah Berkunjung</p>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\ipos-system\resources\views/transaction/receipt_transaction.blade.php ENDPATH**/ ?>