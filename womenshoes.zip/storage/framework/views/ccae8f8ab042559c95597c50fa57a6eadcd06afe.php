
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/manage_account/access/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row page-title-header">
  <div class="col-12">
    <div class="page-header d-flex justify-content-between align-items-center row">
      <h4 class="page-title col-8">Hak Akses</h4>
      <div class="input-group big-search col-4 text-right">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="mdi mdi-magnify search-icon"></i>
          </div>
        </div>
        <input type="text" class="form-control form-control-lg mr-2" name="search" placeholder="Cari data">
      </div>
      <div class="dropdown small-search col-4 text-right" hidden="">
        <button class="btn btn-icons btn-inverse-primary btn-new shadow-sm mr-2" type="button" id="dropdownMenuIconButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="mdi mdi-magnify"></i>
        </button>
        <div class="dropdown-menu search-dropdown" aria-labelledby="dropdownMenuIconButton1">
          <div class="row">
            <div class="col-11">
              <input type="text" class="form-control" name="search" placeholder="Cari data">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="card card-noborder b-radius">
      <div class="card-body">
        <div class="row">
        	<div class="col-12 table-responsive">
        		<table class="table table-custom">
              <thead>
                <tr>
                  <th>Nama</th>
                  <th class="text-center b-left">Kelola Akun</th>
                  <th class="text-center b-left">Kelola Barang</th>
                  <th class="text-center b-left">Transaksi</th>
                  <th class="text-center b-left">Kelola Laporan</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $access; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              	<tr>
                  <td>
                    <span class="d-flex justify-content-start align-items-center">
                      <img src="<?php echo e(asset('pictures/' . $user->foto)); ?>">
                      <span class="ml-2">
                        <span class="d-block mb-1"><?php echo e($user->nama); ?></span>
                        <span class="txt-user-desc"><?php echo e($user->role); ?> <i class="mdi mdi-checkbox-blank-circle dot"></i> <?php echo e($user->email); ?></span>
                      </span>
                    </span>
                  </td>
                  <td class="text-center b-left" data-access="kelola_akun" data-user="<?php echo e($user->user); ?>" data-role="<?php echo e($user->role); ?>">
                    <?php if($user->kelola_akun == 1): ?>
                    <div class="btn-checkbox btn-access">
                        <i class="mdi mdi-checkbox-marked"></i>
                    </div>
                    <?php else: ?>
                    <div class="btn-checkbox btn-non-access">
                        <i class="mdi mdi-checkbox-blank-outline"></i>
                    </div>
                    <?php endif; ?>
                  </td>
                  <td class="text-center b-left" data-access="kelola_barang" data-user="<?php echo e($user->user); ?>" data-role="<?php echo e($user->role); ?>">
                    <?php if($user->kelola_barang == 1): ?>
                    <div class="btn-checkbox btn-access">
                        <i class="mdi mdi-checkbox-marked"></i>
                    </div>
                    <?php else: ?>
                    <div class="btn-checkbox btn-non-access">
                        <i class="mdi mdi-checkbox-blank-outline"></i>
                    </div>
                    <?php endif; ?>
                  </td>
                  <td class="text-center b-left" data-access="transaksi" data-user="<?php echo e($user->user); ?>" data-role="<?php echo e($user->role); ?>">
                    <?php if($user->transaksi == 1): ?>
                    <div class="btn-checkbox btn-access">
                        <i class="mdi mdi-checkbox-marked"></i>
                    </div>
                    <?php else: ?>
                    <div class="btn-checkbox btn-non-access">
                        <i class="mdi mdi-checkbox-blank-outline"></i>
                    </div>
                    <?php endif; ?>
                  </td>
                  <td class="text-center b-left" data-access="kelola_laporan" data-user="<?php echo e($user->user); ?>" data-role="<?php echo e($user->role); ?>">
                    <?php if($user->kelola_laporan == 1): ?>
                    <div class="btn-checkbox btn-access">
                        <i class="mdi mdi-checkbox-marked"></i>
                    </div>
                    <?php else: ?>
                    <div class="btn-checkbox btn-non-access">
                        <i class="mdi mdi-checkbox-blank-outline"></i>
                    </div>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        	</div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/manage_account/access/script.js')); ?>"></script>
<script type="text/javascript">
  function refreshNav(){
    $.ajax({
      url: "<?php echo e(url('/access/sidebar')); ?>",
      method: "GET",
      success:function(data){
        $('#sidebar').html(data);
      }
    });
  }

  $(document).on('click', '.btn-checkbox', function(){
    var data_access = $(this).parent().attr('data-access');
    var data_user = $(this).parent().attr('data-user');
    var data_role = $(this).parent().attr('data-role');
    if(data_role == 'admin'){
      swal({
        title: "Apa anda yakin?",
        text: "Program menyarankan untuk tidak mengubah hak akses admin",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          swal("Sedang diproses....", {
            buttons: false,
            timer: 1000,
          });
          $.ajax({
            url: "<?php echo e(url('/access/change')); ?>/" + data_user + '/' + data_access,
            method: "GET",
            success:function(data_1){
              var my_account = "<?php echo e(auth()->user()->id); ?>";
              $.ajax({
                url: "<?php echo e(url('/access/check')); ?>/" + my_account,
                method: "GET",
                success:function(data_2){
                  if(data_2 == 'benar'){
                    $('tbody').html(data_1);
                    refreshNav();
                  }else{
                    window.open("<?php echo e(url('/dashboard')); ?>", "_self");
                  }
                }
              });
            }
          }); 
        }
      });
    }else{
      swal("Sedang diproses....", {
        buttons: false,
        timer: 1000,
      });
      $.ajax({
        url: "<?php echo e(url('/access/change')); ?>/" + data_user + '/' + data_access,
        method: "GET",
        success:function(data_1){
          var my_account = "<?php echo e(auth()->user()->id); ?>";
          $.ajax({
            url: "<?php echo e(url('/access/check')); ?>/" + my_account,
            method: "GET",
            success:function(data_2){
              if(data_2 == 'benar'){
                $('tbody').html(data_1);
                refreshNav();
              }else{
                window.open("<?php echo e(url('/dashboard')); ?>", "_self");
              }
            }
          });
        }
      });
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ipos-system\resources\views/manage_account/access.blade.php ENDPATH**/ ?>