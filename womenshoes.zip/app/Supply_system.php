<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supply_system extends Model
{
    // Initialize
    protected $fillable = [
        'status',
    ];
}
